package com.cg.employeemaintenancesystem.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.employeemaintenancesystem.beans.EmployeeBean;
import com.cg.employeemaintenancesystem.beans.EmployeeDetails;
import com.cg.employeemaintenancesystem.beans.UserBean;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;

public interface IEmployeeService {
public EmployeeDetails idSearch(String id) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> firstNameSearch(String firstName) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> lastNameSearch(String lastName) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> deptSearch(String department) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> gradeSearch(String grade) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> maritalStatusSearch(String maritalStatus) throws SQLException, EmployeeMaintenanceException;
public int insertLeaveDetails(EmployeeDetails ed) throws SQLException, EmployeeMaintenanceException;
public UserBean getUserType(UserBean user) throws SQLException, EmployeeMaintenanceException;
public boolean addEmployee(EmployeeBean emp) throws SQLException, EmployeeMaintenanceException;
public boolean checkEmpid(String emyid) throws SQLException, EmployeeMaintenanceException;
public boolean checkSalary(String grade, int salary) throws SQLException, EmployeeMaintenanceException;
public boolean modifyEmployee(EmployeeBean emp) throws SQLException, EmployeeMaintenanceException;
public ArrayList<EmployeeDetails> display() throws SQLException, EmployeeMaintenanceException;
public String leaveGrantDecision(String userId) throws SQLException, EmployeeMaintenanceException;
public boolean approval(UserBean user) throws SQLException, EmployeeMaintenanceException;
public boolean rejection(UserBean user)throws SQLException, EmployeeMaintenanceException;
}
